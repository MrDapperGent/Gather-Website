/*
*  Soldat Clicker v1.2
*   By ramirez
*
*

  How to load:
*
    /load -rs soldat_clicker.mrc
*
*

   Description:
*   mIRC Soldat Clicker allows players quickly and easily share
* 

   server information with each other, without the need of
*
   editing favorites, copy/pasting information from IRC to
*
   game, and so on. By simply double clicking a soldat:// link,
*
   you'll join the server automatically, with absolutely no
*
   need of remembering or going through the tedious process of
*
   switching between mIRC and copy/pasting information to Soldat.
*

   The script also allows you to change a few settings with a popup,
*
   such as do you want to join as a player or a spectator, or do
* 
   you play in windowed or fullscreen. It also lets registered
*
   players to switch profiles.
*
*  Syntax:
*    soldat://host:port/password
*

   IP address be an ip address in a dotted format, or a host name,
* 
   such as server.selfkill.com. Port and password are optional,
*  
   if they aren't specified defaults are assumed. Default port
*
   is 23073 and there is no password by default. You can specify
* 
   a password without specifying port as well.
*
*  Examples:
*  
  soldat://server.selfkill.com  
  Joins server.selfkill.com on port 23073
* 
   soldat://85.131.237.138:9000 =  Joins server 85.131.237.138 on port 9000
* 
    
   soldat://server.selfkill.com/abc = joins server.selfkill.com on port 23073 and password abc
*
     soldat://85.131.237.138:9000/abc = Joins 85.131.237.138 on port 9000 and password abc
*/
   